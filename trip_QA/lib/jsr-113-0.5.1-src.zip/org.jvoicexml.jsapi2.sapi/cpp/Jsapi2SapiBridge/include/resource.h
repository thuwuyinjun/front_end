//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by coffee.rc
//
#define IDC_MYICON                      2
#define IDS_APP_TITLE                   103
#define IDS_HELLO                       106
#define IDI_COFFEE                      107
#define IDI_SMALL                       108
#define IDC_COFFEE                      109
#define IDS_ERRORSTRING                 110
#define IDS_ENTERSTORE                  111
#define IDS_WELCOME                     112
#define IDS_PLEASEORDER                 113
#define IDS_PLEASEWAIT                  114
#define IDS_FAILEDINIT                  114
#define IDS_BASE                        115
#define IDS_BASE1                       116
#define IDS_BASE2                       117
#define IDS_BASE3                       118
#define IDS_BASE4                       119
#define IDS_BASE5                       120
#define IDS_BASE6                       121
#define IDS_BASE7                       122
#define IDS_BASE8                       123
#define IDS_BASE9                       124
#define IDS_BASE10                      125
#define IDS_BASE11                      126
#define IDS_BASE12                      127
#define IDR_MAINFRAME                   128
#define IDS_BASE13                      128
#define IDR_CMD_CFG                     129
#define IDS_BASE14                      129
#define IDS_BASE15                      130
#define IDB_BITMAP1                     130
#define IDS_BASE16                      131
#define IDS_BASE17                      132
#define IDS_BASE18                      133
#define IDS_BASE19                      134
#define IDS_BASE20                      135
#define IDS_ORDERBEGIN                  136
#define IDS_ORDEREND                    137
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
